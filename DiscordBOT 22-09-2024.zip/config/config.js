// config/config.js
module.exports = {
    prefix: '!', // O el prefijo que estés usando
    welcomeChannelId: 'ID_DEL_CANAL_DE_BIENVENIDA',
    enablePeriodicMessages: false // Cambia a false para desactivar los mensajes periódicos
};
